    <footer class="bg-dark bottom-0">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">teste</div>
                <div class="col-lg-4"></div>
                <div class="col-lg-4"></div>
            </div>
        </div>
    
    </footer>    
    
    
    <?php wp_footer(); ?>
    </body>
</html>